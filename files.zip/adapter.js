/* =========================================================
   ADAPTER — ponte entre o banco novo (data/dinos.json) e o
   index.html atual, que ainda espera o formato antigo
   (nome, latim, altura, comprimento, peso, periodo{inicio,fim},
   classificacao{classe,ordem,familia}, descoberta{por,ano}...).

   COMO USAR:
   1) Apague o "const DINOS = [...]" antigo do index.html.
   2) No lugar, cole isto (ou <script src="data/adapter.js">
      antes do script principal):

        let DINOS = [];
        let DINO_CACHE = null;

        async function loadDinos(){
          const res = await fetch('data/dinos.json');
          const raw = await res.json();
          DINOS = raw.map(adaptDino);
          DINO_CACHE = DINOS;
          return DINO_CACHE;
        }

        function getAllDinos(){
          return DINO_CACHE || DINOS;
        }

   3) Tudo o que já funciona (busca, comparador, cartas, etc.)
      continua funcionando, porque adaptDino() devolve exatamente
      os mesmos nomes de campo de antes. Os campos novos (uuid,
      slug, classificacao completa, medidas, imagens, tags...)
      continuam disponíveis em cada objeto, só não são obrigatórios
      pra tela atual — ficam prontos pra quando vocês construírem
      a ficha v1.1 e o comparador v2.0.
   ========================================================= */

function adaptDino(d){
  return {
    // ----- campos que o site atual já usa -----
    id: d.id,
    nome: d.nome,
    latim: d.cientifico,
    era: d.periodo.era,
    dieta: d.dieta,
    comprimento: d.medidas.comprimento,
    peso: d.medidas.peso,
    regiao: d.regiao,
    forma: d.forma,
    desc: d.desc,
    fato: d.fato,
    perigo: d.perigo,
    velocidade: d.velocidade,
    altura: d.medidas.altura,
    periodo: { inicio: d.periodo.inicio, fim: d.periodo.fim },
    formacao: d.formacao,
    local: d.local,
    mapa: d.mapa,
    classificacao: {
      classe: d.classificacao.classe,
      ordem: d.classificacao.ordem,
      familia: d.classificacao.familia
    },
    descoberta: { por: d.descoberta.pessoa, ano: d.descoberta.ano },

    // ----- campos novos, disponíveis desde já -----
    uuid: d.uuid,
    slug: d.slug,
    status: d.status,
    subperiodo: d.periodo.estagio,
    grupo: d.grupo,
    continente: d.continente,
    dietaDetalhe: d.dietaDetalhe,
    curiosidades: d.curiosidades,
    comparacaoHumano: d.comparacaoHumano,
    imagens: d.imagens,
    tags: d.tags,
    fontes: d.fontes,
    classificacaoCompleta: d.classificacao, // reino, filo, classe, ordem, familia, genero, especie
    descobertaCompleta: d.descoberta        // ano, pessoa, pais, fossilOriginal
  };
}

// Uso pronto (Node/bundler). Em navegador puro, use a versão
// com <script> comum e remova esta linha de export.
if (typeof module !== "undefined") module.exports = { adaptDino };
